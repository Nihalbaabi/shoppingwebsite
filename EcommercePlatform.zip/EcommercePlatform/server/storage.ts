import { 
  categories, 
  products, 
  orders, 
  orderItems,
  type Category, 
  type InsertCategory, 
  type Product, 
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem
} from "@shared/schema";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  getFeaturedCategories(): Promise<Category[]>;
  
  // Products
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  
  // Orders
  createOrder(order: InsertOrder): Promise<Order>;
  getOrderById(id: number): Promise<Order | undefined>;
  getOrders(): Promise<Order[]>;
  
  // Order Items
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
  getOrderItemsByOrderId(orderId: number): Promise<OrderItem[]>;
}

export class MemStorage implements IStorage {
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  
  private categoryId: number;
  private productId: number;
  private orderId: number;
  private orderItemId: number;
  
  constructor() {
    this.categories = new Map();
    this.products = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    
    this.categoryId = 1;
    this.productId = 1;
    this.orderId = 1;
    this.orderItemId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }
  
  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getFeaturedCategories(): Promise<Category[]> {
    return Array.from(this.categories.values()).filter(category => category.featured);
  }
  
  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }
  
  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }
  
  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.categoryId === categoryId);
  }
  
  async searchProducts(query: string): Promise<Product[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(product => 
      product.name.toLowerCase().includes(lowerQuery) || 
      product.description.toLowerCase().includes(lowerQuery)
    );
  }
  
  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.products.values()).filter(product => product.isFeatured);
  }
  
  // Orders
  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    // Make sure all required fields are present for the Order type
    const order: Order = { 
      ...insertOrder, 
      id,
      status: insertOrder.status ?? 'pending'
    };
    this.orders.set(id, order);
    return order;
  }
  
  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }
  
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }
  
  // Order Items
  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemId++;
    const orderItem: OrderItem = { ...insertOrderItem, id };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }
  
  async getOrderItemsByOrderId(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(item => item.orderId === orderId);
  }
  
  // Initialize with sample data
  private initializeData() {
    // Categories
    const categoryData: InsertCategory[] = [
      { name: "Clothing", description: "Fashionable apparel", icon: "fas fa-tshirt", featured: true, imageUrl: "https://images.unsplash.com/photo-1445205170230-053b83016050?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=200&q=80" },
      { name: "Electronics", description: "Latest gadgets", icon: "fas fa-mobile-alt", featured: true, imageUrl: "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=200&q=80" },
      { name: "Home", description: "Home decor and furniture", icon: "fas fa-home", featured: true, imageUrl: "https://images.unsplash.com/photo-1484101403633-562f891dc89a?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=200&q=80" },
      { name: "Kitchen", description: "Kitchen appliances and tools", icon: "fas fa-utensils", featured: false, imageUrl: "" },
      { name: "Health", description: "Health and wellness products", icon: "fas fa-heartbeat", featured: false, imageUrl: "" },
      { name: "Toys", description: "Toys and games", icon: "fas fa-gamepad", featured: false, imageUrl: "" },
      { name: "Beauty", description: "Beauty and personal care", icon: "fas fa-spa", featured: true, imageUrl: "https://images.unsplash.com/photo-1470309864661-68328b2cd0a5?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=200&q=80" },
      { name: "Accessories", description: "Fashion accessories", icon: "fas fa-ring", featured: false, imageUrl: "" },
      { name: "Footwear", description: "Shoes and boots", icon: "fas fa-shoe-prints", featured: false, imageUrl: "" },
      { name: "Audio", description: "Audio devices", icon: "fas fa-headphones", featured: false, imageUrl: "" },
      { name: "Photography", description: "Cameras and equipment", icon: "fas fa-camera", featured: false, imageUrl: "" },
      { name: "Tech", description: "Technology gadgets", icon: "fas fa-laptop", featured: false, imageUrl: "" },
      { name: "Bags", description: "Bags and luggage", icon: "fas fa-shopping-bag", featured: false, imageUrl: "" }
    ];
    
    categoryData.forEach(cat => {
      const id = this.categoryId++;
      // Ensure all required fields are present
      this.categories.set(id, { 
        ...cat, 
        id,
        description: cat.description ?? null,
        featured: cat.featured ?? false,
        imageUrl: cat.imageUrl ?? null
      });
    });
    
    // Products
    const productData: InsertProduct[] = [
      {
        name: "Premium Watch",
        description: "The Premium Watch is a beautifully crafted timepiece featuring Swiss movement for precise timekeeping, Sapphire crystal glass for scratch resistance, 100m water resistance for everyday use, Genuine leather strap with stainless steel buckle, and 2-year international warranty. Perfect for both casual and formal occasions, this watch combines classic design with modern functionality.",
        price: 129.99,
        rating: 4.5,
        reviewCount: 24,
        categoryId: this.findCategoryIdByName("Accessories"),
        inStock: true,
        isFeatured: true,
        isNew: false,
        mainImage: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
          "https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
          "https://images.unsplash.com/photo-1434056886845-dac89ffe9b56?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
          "https://images.unsplash.com/photo-1526045612212-70caf35c14df?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      },
      {
        name: "Wireless Headphones",
        description: "Premium wireless headphones with active noise cancellation, 30-hour battery life, and studio-quality sound. Features Bluetooth 5.0 connectivity and comfortable over-ear design.",
        price: 89.99,
        rating: 5.0,
        reviewCount: 42,
        categoryId: this.findCategoryIdByName("Electronics"),
        inStock: true,
        isFeatured: true,
        isNew: false,
        mainImage: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      },
      {
        name: "Running Sneakers",
        description: "Lightweight running sneakers with responsive cushioning and breathable mesh upper. Designed for optimal performance and comfort during long runs.",
        price: 119.99,
        rating: 4.0,
        reviewCount: 18,
        categoryId: this.findCategoryIdByName("Footwear"),
        inStock: true,
        isFeatured: true,
        isNew: false,
        mainImage: "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      },
      {
        name: "Leather Backpack",
        description: "Handcrafted genuine leather backpack with laptop compartment and multiple pockets. Perfect for daily commute or weekend getaways.",
        price: 79.99,
        salePrice: 99.99,
        rating: 3.5,
        reviewCount: 32,
        categoryId: this.findCategoryIdByName("Bags"),
        inStock: true,
        isFeatured: true,
        isNew: false,
        mainImage: "https://images.unsplash.com/photo-1596707545790-0f9a244dc2a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1596707545790-0f9a244dc2a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      },
      {
        name: "Polaroid Camera",
        description: "Instant film camera that prints photos immediately after capture. Includes advanced flash system and classic retro design.",
        price: 69.99,
        rating: 4.0,
        reviewCount: 14,
        categoryId: this.findCategoryIdByName("Photography"),
        inStock: true,
        isFeatured: true,
        isNew: false,
        mainImage: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      },
      {
        name: "Smart Watch",
        description: "Advanced smartwatch with health monitoring, GPS, and smartphone notifications. Water-resistant design with 5-day battery life.",
        price: 149.99,
        rating: 4.5,
        reviewCount: 56,
        categoryId: this.findCategoryIdByName("Tech"),
        inStock: true,
        isFeatured: true,
        isNew: false,
        mainImage: "https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1587563871167-1ee9c731aefb?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      },
      {
        name: "Sport Shoes",
        description: "Versatile athletic shoes for various sports activities. Features enhanced stability, cushioning, and grip for superior performance.",
        price: 89.99,
        rating: 5.0,
        reviewCount: 8,
        categoryId: this.findCategoryIdByName("Footwear"),
        inStock: true,
        isFeatured: true,
        isNew: true,
        mainImage: "https://images.unsplash.com/photo-1491553895911-0055eca6402d?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1491553895911-0055eca6402d?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      },
      {
        name: "Wireless Earbuds",
        description: "True wireless earbuds with immersive sound, touch controls, and 24-hour battery life. Includes compact charging case and multiple ear tips.",
        price: 59.99,
        rating: 4.0,
        reviewCount: 27,
        categoryId: this.findCategoryIdByName("Audio"),
        inStock: true,
        isFeatured: true,
        isNew: false,
        mainImage: "https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80",
        images: [
          "https://images.unsplash.com/photo-1560343090-f0409e92791a?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=600&q=80"
        ]
      }
    ];
    
    productData.forEach(prod => {
      const id = this.productId++;
      // Ensure all required fields are present
      this.products.set(id, { 
        ...prod, 
        id,
        salePrice: prod.salePrice ?? null,
        rating: prod.rating ?? null,
        reviewCount: prod.reviewCount ?? null,
        inStock: prod.inStock ?? null,
        isFeatured: prod.isFeatured ?? null,
        isNew: prod.isNew ?? null,
        images: prod.images ?? null
      });
    });
    
    // Add some sample orders
    const orderData: InsertOrder[] = [
      {
        customerName: "John Smith",
        address: "123 Main St, Anytown",
        zipcode: "94581",
        status: "completed",
        total: 219.98,
        createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString() // 14 days ago
      },
      {
        customerName: "Sarah Johnson",
        address: "456 Oak Ave, Springfield",
        zipcode: "62701",
        status: "completed",
        total: 89.99,
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days ago
      },
      {
        customerName: "Michael Brown",
        address: "789 Pine St, Westville",
        zipcode: "10001",
        status: "pending",
        total: 149.99,
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() // 1 day ago
      }
    ];
    
    // Add orders
    orderData.forEach(order => {
      const id = this.orderId++;
      this.orders.set(id, {
        ...order,
        id,
        status: order.status ?? 'pending'
      });
    });
    
    // Add order items
    const orderItemsData: InsertOrderItem[] = [
      // Items for first order (John Smith)
      {
        orderId: 1,
        productId: 1, // Premium Watch
        quantity: 1,
        price: 129.99
      },
      {
        orderId: 1,
        productId: 2, // Wireless Headphones
        quantity: 1,
        price: 89.99
      },
      // Items for second order (Sarah Johnson)
      {
        orderId: 2,
        productId: 2, // Wireless Headphones
        quantity: 1,
        price: 89.99
      },
      // Items for third order (Michael Brown)
      {
        orderId: 3,
        productId: 6, // Smart Watch
        quantity: 1,
        price: 149.99
      }
    ];
    
    // Add order items
    orderItemsData.forEach(item => {
      const id = this.orderItemId++;
      this.orderItems.set(id, { ...item, id });
    });
  }
  
  private findCategoryIdByName(name: string): number {
    // Convert to array first, then find
    const categoryArray = Array.from(this.categories.entries());
    const categoryEntry = categoryArray.find(([_, category]) => category.name === name);
    
    if (categoryEntry) {
      return categoryEntry[0];
    }
    
    return 1; // Default to first category if not found
  }
}

export const storage = new MemStorage();
