import { 
  createContext, 
  useState, 
  useEffect, 
  ReactNode 
} from "react";
import { 
  CartItem, 
  Product 
} from "@shared/schema";
import { 
  addOrUpdateCartItem, 
  findCartItemByProductId, 
  removeCartItem, 
  updateCartItemQuantity, 
  getTotalItems
} from "@/lib/cart";

interface CartContextType {
  cartItems: CartItem[];
  totalItems: number;
  addToCart: (product: Product, quantity: number, color?: string) => void;
  removeFromCart: (productId: number, color?: string) => void;
  updateQuantity: (productId: number, quantity: number, color?: string) => void;
  increaseQuantity: (productId: number, color?: string) => void;
  decreaseQuantity: (productId: number, color?: string) => void;
  clearCart: () => void;
}

export const CartContext = createContext<CartContextType | undefined>(undefined);

interface CartProviderProps {
  children: ReactNode;
}

const CART_STORAGE_KEY = "shopease_cart";

export const CartProvider = ({ children }: CartProviderProps) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [totalItems, setTotalItems] = useState(0);

  // Load cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem(CART_STORAGE_KEY);
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart);
        setCartItems(parsedCart);
        setTotalItems(getTotalItems(parsedCart));
      } catch (error) {
        console.error("Failed to parse cart from localStorage:", error);
      }
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartItems));
    setTotalItems(getTotalItems(cartItems));
  }, [cartItems]);

  const addToCart = (product: Product, quantity: number, color?: string) => {
    setCartItems(prevItems => addOrUpdateCartItem(prevItems, product, quantity, color));
  };

  const removeFromCart = (productId: number, color?: string) => {
    setCartItems(prevItems => removeCartItem(prevItems, productId, color));
  };

  const updateQuantity = (productId: number, quantity: number, color?: string) => {
    if (quantity <= 0) {
      removeFromCart(productId, color);
      return;
    }
    
    setCartItems(prevItems => updateCartItemQuantity(prevItems, productId, quantity, color));
  };

  const increaseQuantity = (productId: number, color?: string) => {
    setCartItems(prevItems => {
      const item = findCartItemByProductId(prevItems, productId, color);
      if (!item) return prevItems;
      
      return updateCartItemQuantity(
        prevItems, 
        productId, 
        item.quantity + 1,
        color
      );
    });
  };

  const decreaseQuantity = (productId: number, color?: string) => {
    setCartItems(prevItems => {
      const item = findCartItemByProductId(prevItems, productId, color);
      if (!item) return prevItems;
      
      return item.quantity > 1 
        ? updateCartItemQuantity(prevItems, productId, item.quantity - 1, color)
        : removeCartItem(prevItems, productId, color);
    });
  };

  const clearCart = () => {
    setCartItems([]);
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        totalItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        increaseQuantity,
        decreaseQuantity,
        clearCart
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
