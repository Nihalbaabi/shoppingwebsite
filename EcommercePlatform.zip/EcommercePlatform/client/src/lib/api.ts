// API endpoint constants

// Category endpoints
export const API_CATEGORIES = '/api/categories';
export const API_CATEGORIES_FEATURED = '/api/categories/featured';
export const API_CATEGORY_BY_ID = (id: number) => `/api/categories/${id}`;
export const API_CATEGORY_PRODUCTS = (categoryId: number) => `/api/categories/${categoryId}/products`;

// Product endpoints
export const API_PRODUCTS = '/api/products';
export const API_PRODUCTS_FEATURED = '/api/products/featured';
export const API_PRODUCTS_SEARCH = (query: string) => `/api/products/search?q=${encodeURIComponent(query)}`;
export const API_PRODUCT_BY_ID = (id: number) => `/api/products/${id}`;

// Order endpoints
export const API_ORDERS = '/api/orders';
export const API_ORDER_BY_ID = (id: number) => `/api/orders/${id}`;
export const API_ORDER_ITEMS = (orderId: number) => `/api/orders/${orderId}/items`;

/**
 * Helper function to fetch data from API
 * @param url API endpoint URL
 * @returns Promise with JSON data
 */
export const fetchData = async (url: string) => {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Error fetching data from ${url}: ${response.statusText}`);
  }
  return response.json();
};

/**
 * Helper function to post data to API
 * @param url API endpoint URL
 * @param data Data to post
 * @returns Promise with JSON response
 */
export const postData = async (url: string, data: any) => {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });
  
  if (!response.ok) {
    throw new Error(`Error posting data to ${url}: ${response.statusText}`);
  }
  return response.json();
};