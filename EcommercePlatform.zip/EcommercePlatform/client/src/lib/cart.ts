import { CartItem, Product } from "@shared/schema";

// Format currency
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

// Calculate cart subtotal
export const calculateSubtotal = (items: CartItem[]): number => {
  return items.reduce((total, item) => {
    const price = item.product.salePrice || item.product.price;
    return total + (price * item.quantity);
  }, 0);
};

// Calculate tax amount (8% tax rate)
export const calculateTax = (subtotal: number): number => {
  return subtotal * 0.08;
};

// Calculate order total
export const calculateTotal = (subtotal: number, tax: number, shipping: number = 0): number => {
  return subtotal + tax + shipping;
};

// Get total number of items in cart
export const getTotalItems = (items: CartItem[]): number => {
  return items.reduce((count, item) => count + item.quantity, 0);
};

// Find cart item by product ID
export const findCartItemByProductId = (
  items: CartItem[],
  productId: number,
  color?: string
): CartItem | undefined => {
  return items.find(
    (item) => 
      item.productId === productId && 
      (color ? item.color === color : true)
  );
};

// Create a cart item from product
export const createCartItem = (
  product: Product,
  quantity: number = 1,
  color?: string
): CartItem => {
  return {
    productId: product.id,
    quantity,
    color,
    product
  };
};

// Update quantity of existing cart item
export const updateCartItemQuantity = (
  items: CartItem[],
  productId: number,
  quantity: number,
  color?: string
): CartItem[] => {
  return items.map(item => {
    if (
      item.productId === productId &&
      (color ? item.color === color : true)
    ) {
      return { ...item, quantity };
    }
    return item;
  });
};

// Remove item from cart
export const removeCartItem = (
  items: CartItem[],
  productId: number,
  color?: string
): CartItem[] => {
  return items.filter(
    item => 
      !(item.productId === productId && 
      (color ? item.color === color : true))
  );
};

// Add item to cart (or update if already exists)
export const addOrUpdateCartItem = (
  items: CartItem[],
  product: Product,
  quantity: number = 1,
  color?: string
): CartItem[] => {
  const existingItem = findCartItemByProductId(items, product.id, color);
  
  if (existingItem) {
    return updateCartItemQuantity(
      items,
      product.id,
      existingItem.quantity + quantity,
      color
    );
  } else {
    return [...items, createCartItem(product, quantity, color)];
  }
};
