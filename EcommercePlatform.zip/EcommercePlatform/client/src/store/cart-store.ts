import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { nanoid } from 'nanoid';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { Product } from '@shared/schema';

interface CartItem {
  id: number;
  productId: number;
  quantity: number;
  cartId: string;
  product: Product;
}

interface CartState {
  cartId: string;
  items: CartItem[];
  isOpen: boolean;
  isLoading: boolean;
  
  // Actions
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  
  // Cart operations
  addItem: (product: Product, quantity?: number) => Promise<void>;
  updateItemQuantity: (itemId: number, quantity: number) => Promise<void>;
  removeItem: (itemId: number) => Promise<void>;
  clearCart: () => Promise<void>;
  
  // Getters
  getSubtotal: () => number;
  getTotalItems: () => number;
  refreshCart: () => Promise<void>;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      cartId: nanoid(),
      items: [],
      isOpen: false,
      isLoading: false,
      
      openCart: () => set({ isOpen: true }),
      closeCart: () => set({ isOpen: false }),
      toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),
      
      addItem: async (product, quantity = 1) => {
        set({ isLoading: true });
        try {
          const cartId = get().cartId;
          const response = await apiRequest("POST", "/api/cart/items", { 
            productId: product.id, 
            quantity, 
            cartId
          });
          
          if (response.ok) {
            await get().refreshCart();
            set({ isOpen: true });
          }
        } catch (error) {
          console.error("Failed to add item to cart:", error);
        } finally {
          set({ isLoading: false });
        }
      },
      
      updateItemQuantity: async (itemId, quantity) => {
        set({ isLoading: true });
        try {
          const response = await apiRequest("PATCH", `/api/cart/items/${itemId}`, { quantity });
          
          if (response.ok) {
            await get().refreshCart();
          }
        } catch (error) {
          console.error("Failed to update item quantity:", error);
        } finally {
          set({ isLoading: false });
        }
      },
      
      removeItem: async (itemId) => {
        set({ isLoading: true });
        try {
          const response = await apiRequest("DELETE", `/api/cart/items/${itemId}`);
          
          if (response.ok) {
            await get().refreshCart();
          }
        } catch (error) {
          console.error("Failed to remove item from cart:", error);
        } finally {
          set({ isLoading: false });
        }
      },
      
      clearCart: async () => {
        set({ isLoading: true });
        try {
          const { items } = get();
          
          // Remove all items one by one
          for (const item of items) {
            await apiRequest("DELETE", `/api/cart/items/${item.id}`);
          }
          
          set({ items: [] });
        } catch (error) {
          console.error("Failed to clear cart:", error);
        } finally {
          set({ isLoading: false });
        }
      },
      
      getSubtotal: () => {
        return get().items.reduce((total, item) => {
          const price = item.product.salePrice || item.product.price;
          return total + (price * item.quantity);
        }, 0);
      },
      
      getTotalItems: () => {
        return get().items.reduce((count, item) => count + item.quantity, 0);
      },
      
      refreshCart: async () => {
        set({ isLoading: true });
        try {
          const cartId = get().cartId;
          const response = await fetch(`/api/cart/${cartId}`);
          
          if (response.ok) {
            const data = await response.json();
            set({ items: data.items });
          }
        } catch (error) {
          console.error("Failed to refresh cart:", error);
        } finally {
          set({ isLoading: false });
        }
      }
    }),
    {
      name: 'shop-cart-storage',
      partialize: (state) => ({ cartId: state.cartId }),
    }
  )
);
