import { useQuery } from "@tanstack/react-query";
import type { Product } from "@shared/schema";

export const useProducts = () => {
  const { 
    data: products,
    isLoading,
    isError
  } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const getProductById = (id: number) => {
    return products?.find(product => product.id === id);
  };

  const getFeaturedProducts = () => {
    return products?.filter(product => product.isFeatured) || [];
  };

  const getNewProducts = () => {
    return products?.filter(product => product.isNew) || [];
  };

  return {
    products: products || [],
    isLoading,
    isError,
    getProductById,
    getFeaturedProducts,
    getNewProducts
  };
};
