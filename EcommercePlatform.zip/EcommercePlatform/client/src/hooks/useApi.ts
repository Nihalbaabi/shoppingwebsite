import { useState, useEffect } from 'react';
import { fetchData, postData } from '../lib/api';

/**
 * Custom hook for fetching data from API
 * @param url API endpoint URL
 * @param dependencies Array of dependencies to trigger refetch
 * @returns Object with data, loading state, error, and refetch function
 */
export function useFetch<T>(url: string, dependencies: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchDataFromApi = async () => {
    setLoading(true);
    try {
      const result = await fetchData(url);
      setData(result);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err : new Error(String(err)));
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDataFromApi();
  }, [url, ...dependencies]);

  // Function to manually trigger a refetch
  const refetch = () => {
    fetchDataFromApi();
  };

  return { data, loading, error, refetch };
}

/**
 * Custom hook for posting data to API
 * @returns Object with submission function, loading state, and error
 */
export function usePost<T, R>() {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [response, setResponse] = useState<R | null>(null);

  const submit = async (url: string, data: T) => {
    setLoading(true);
    try {
      const result = await postData(url, data);
      setResponse(result);
      setError(null);
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error(String(err)));
      setResponse(null);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { submit, loading, error, response };
}