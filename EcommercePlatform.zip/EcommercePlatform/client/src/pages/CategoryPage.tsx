import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import ProductCard from "@/components/product/ProductCard";
import ProductDetail from "@/components/product/ProductDetail";
import { Product, Category } from "@shared/schema";

export default function CategoryPage() {
  const [_, params] = useRoute("/category/:id");
  const categoryId = params?.id ? parseInt(params.id) : null;
  
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [selectedSortOption, setSelectedSortOption] = useState("Most Popular");

  const { data: category, isLoading: isCategoryLoading } = useQuery({
    queryKey: ["/api/categories", categoryId],
    enabled: categoryId !== null,
  });

  const { data: products, isLoading: isProductsLoading } = useQuery({
    queryKey: ["/api/categories", categoryId, "products"],
    enabled: categoryId !== null,
  });

  const { data: selectedProduct, isLoading: isProductDetailLoading } = useQuery({
    queryKey: ["/api/products", selectedProductId],
    enabled: selectedProductId !== null,
  });

  const handleViewProductDetails = (productId: number) => {
    setSelectedProductId(productId);
  };

  const handleCloseProductDetail = () => {
    setSelectedProductId(null);
  };

  // Sort products based on selected option
  const sortProducts = (products: Product[]) => {
    if (!products) return [];
    
    const productsCopy = [...products];
    
    switch (selectedSortOption) {
      case "Newest":
        return productsCopy.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
      case "Price: Low to High":
        return productsCopy.sort((a, b) => a.price - b.price);
      case "Price: High to Low":
        return productsCopy.sort((a, b) => b.price - a.price);
      default: // Most Popular
        return productsCopy.sort((a, b) => b.reviewCount - a.reviewCount);
    }
  };

  const displayedProducts = products ? sortProducts(products) : [];

  if (!categoryId) {
    return <div className="container mx-auto px-4 py-10">Category not found</div>;
  }

  return (
    <main className="container mx-auto px-4 py-8">
      {/* Category Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">
          {isCategoryLoading ? (
            <div className="bg-gray-300 h-10 w-1/3 rounded animate-pulse"></div>
          ) : (
            category?.name
          )}
        </h1>
        <p className="text-gray-600">
          {isCategoryLoading ? (
            <div className="bg-gray-200 h-5 w-2/3 rounded animate-pulse"></div>
          ) : (
            category?.description
          )}
        </p>
      </div>

      {/* Products Section */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">
            {isProductsLoading ? (
              <div className="bg-gray-300 h-7 w-40 rounded animate-pulse"></div>
            ) : (
              `${displayedProducts.length} Products`
            )}
          </h2>
          <div className="flex items-center">
            <label htmlFor="sort" className="mr-2 text-sm hidden md:inline">Sort by:</label>
            <select 
              id="sort" 
              className="border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              value={selectedSortOption}
              onChange={(e) => setSelectedSortOption(e.target.value)}
            >
              <option>Most Popular</option>
              <option>Newest</option>
              <option>Price: Low to High</option>
              <option>Price: High to Low</option>
            </select>
          </div>
        </div>
        
        {isProductsLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {Array(8).fill(0).map((_, index) => (
              <div key={index} className="bg-white rounded-lg shadow overflow-hidden animate-pulse">
                <div className="bg-gray-300 h-48 w-full"></div>
                <div className="p-4">
                  <div className="bg-gray-300 h-4 w-1/3 rounded mb-2"></div>
                  <div className="bg-gray-300 h-5 w-2/3 rounded mb-2"></div>
                  <div className="bg-gray-300 h-3 w-1/2 rounded mb-4"></div>
                  <div className="bg-gray-300 h-8 w-full rounded"></div>
                </div>
              </div>
            ))}
          </div>
        ) : displayedProducts.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {displayedProducts.map((product: Product) => (
              <ProductCard 
                key={product.id}
                product={product}
                onViewDetails={handleViewProductDetails}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-10">
            <p className="text-gray-500">No products found in this category.</p>
          </div>
        )}
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductDetail
          product={selectedProduct}
          isOpen={!!selectedProductId}
          onClose={handleCloseProductDetail}
        />
      )}
    </main>
  );
}
