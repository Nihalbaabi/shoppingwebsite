import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ProductCard from "@/components/product/ProductCard";
import ProductDetail from "@/components/product/ProductDetail";
import { Product, Category } from "@shared/schema";

export default function MainPage() {
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [loadMoreCount, setLoadMoreCount] = useState(8);
  const [selectedSortOption, setSelectedSortOption] = useState("Most Popular");
  const [emailSubscription, setEmailSubscription] = useState("");

  const { data: featuredCategories, isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories/featured"],
  });

  const { data: products, isLoading: isProductsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: selectedProduct, isLoading: isProductDetailLoading } = useQuery<Product>({
    queryKey: ["/api/products", selectedProductId],
    enabled: selectedProductId !== null,
  });

  const handleViewProductDetails = (productId: number) => {
    setSelectedProductId(productId);
  };

  const handleCloseProductDetail = () => {
    setSelectedProductId(null);
  };

  const handleLoadMore = () => {
    setLoadMoreCount(prev => prev + 8);
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailSubscription.trim()) {
      alert(`Thank you for subscribing with: ${emailSubscription}`);
      setEmailSubscription("");
    }
  };

  // Sort products based on selected option
  const sortProducts = (products: Product[]) => {
    if (!products) return [];
    
    const productsCopy = [...products];
    
    switch (selectedSortOption) {
      case "Newest":
        return productsCopy.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
      case "Price: Low to High":
        return productsCopy.sort((a, b) => a.price - b.price);
      case "Price: High to Low":
        return productsCopy.sort((a, b) => b.price - a.price);
      default: // Most Popular
        return productsCopy.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0));
    }
  };

  const displayedProducts = products ? sortProducts(products).slice(0, loadMoreCount) : [];

  return (
    <main>
      {/* Hero banner */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
        <div className="container mx-auto px-4 py-8 md:py-16">
          <div className="md:flex items-center">
            <div className="md:w-1/2 mb-6 md:mb-0">
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Summer Collection 2023</h1>
              <p className="text-lg mb-6">Discover our new arrivals with up to 40% off!</p>
              <Button variant="secondary" size="lg">
                Shop Now
              </Button>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <img 
                src="https://images.unsplash.com/photo-1483985988355-763728e1935b?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80" 
                alt="Summer collection banner" 
                className="rounded-lg shadow-lg max-w-full h-auto"
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Featured Categories */}
      <div className="container mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-6">Featured Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {isCategoriesLoading ? (
            Array(4).fill(0).map((_, index) => (
              <div key={index} className="animate-pulse relative overflow-hidden rounded-lg">
                <div className="bg-gray-300 h-40 w-full"></div>
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="bg-gray-300 h-5 w-20 rounded mb-1"></div>
                  <div className="bg-gray-300 h-3 w-16 rounded"></div>
                </div>
              </div>
            ))
          ) : (
            featuredCategories && featuredCategories.map((category: Category) => (
              <Link 
                key={category.id} 
                href={`/category/${category.id}`}
                className="relative overflow-hidden rounded-lg group"
              >
                <div className="absolute inset-0 bg-gray-900 opacity-40 group-hover:opacity-30 transition"></div>
                <img 
                  src={category.imageUrl || ''} 
                  alt={category.name} 
                  className="w-full h-40 object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                  <h3 className="font-bold">{category.name}</h3>
                  <p className="text-sm">{category.description || ''}</p>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>
      
      {/* Products Section */}
      <div className="bg-white py-8">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Popular Products</h2>
            <div className="flex items-center">
              <label htmlFor="sort" className="mr-2 text-sm hidden md:inline">Sort by:</label>
              <select 
                id="sort" 
                className="border border-gray-300 rounded px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                value={selectedSortOption}
                onChange={(e) => setSelectedSortOption(e.target.value)}
              >
                <option>Most Popular</option>
                <option>Newest</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
              </select>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {isProductsLoading ? (
              Array(8).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-lg shadow overflow-hidden animate-pulse">
                  <div className="bg-gray-300 h-48 w-full"></div>
                  <div className="p-4">
                    <div className="bg-gray-300 h-4 w-1/3 rounded mb-2"></div>
                    <div className="bg-gray-300 h-5 w-2/3 rounded mb-2"></div>
                    <div className="bg-gray-300 h-3 w-1/2 rounded mb-4"></div>
                    <div className="bg-gray-300 h-8 w-full rounded"></div>
                  </div>
                </div>
              ))
            ) : (
              displayedProducts.map((product: Product) => (
                <ProductCard 
                  key={product.id}
                  product={product}
                  onViewDetails={handleViewProductDetails}
                />
              ))
            )}
          </div>
          
          {products && loadMoreCount < products.length && (
            <div className="mt-8 flex justify-center">
              <Button 
                variant="outline"
                onClick={handleLoadMore}
              >
                Load More Products
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Promotion Banner */}
      <div className="container mx-auto px-4 py-8">
        <div className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg overflow-hidden">
          <div className="md:flex items-center">
            <div className="md:w-2/3 p-6 md:p-10">
              <h3 className="text-white text-2xl md:text-3xl font-bold mb-3">New Member Special</h3>
              <p className="text-gray-300 mb-6">Sign up today and get 15% off your first order!</p>
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-4">
                <Input 
                  type="email" 
                  placeholder="Your email address" 
                  value={emailSubscription}
                  onChange={(e) => setEmailSubscription(e.target.value)}
                  required
                />
                <Button type="submit">Subscribe</Button>
              </form>
            </div>
            <div className="md:w-1/3 hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
                alt="Special offer" 
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductDetail
          product={selectedProduct}
          isOpen={!!selectedProductId}
          onClose={handleCloseProductDetail}
        />
      )}
    </main>
  );
}