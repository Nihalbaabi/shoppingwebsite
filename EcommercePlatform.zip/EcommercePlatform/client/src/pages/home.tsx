import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { HeroBanner } from '@/components/hero-banner';
import { FeaturedCategories } from '@/components/featured-categories';
import { ProductGrid } from '@/components/product-grid';
import FilterSidebar from '@/components/filter-sidebar';
import { Category, Product } from '@shared/schema';

export default function Home() {
  const [location] = useLocation();
  
  // Parse URL query parameters
  const queryParams = new URLSearchParams(location.split('?')[1]);
  const searchQuery = queryParams.get('search');
  const categorySlug = queryParams.get('category');
  const minPrice = queryParams.get('minPrice');
  const maxPrice = queryParams.get('maxPrice');
  const rating = queryParams.get('rating');
  const sale = queryParams.get('sale');
  
  // Build API query based on filters
  let apiQuery = '/api/products';
  const apiParams: string[] = [];
  
  // Find category ID from slug
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  useEffect(() => {
    if (categorySlug && categories) {
      const category = categories.find((c) => c.slug === categorySlug);
      if (category) {
        apiParams.push(`categoryId=${category.id}`);
      }
    }
    
    if (minPrice) apiParams.push(`minPrice=${minPrice}`);
    if (maxPrice) apiParams.push(`maxPrice=${maxPrice}`);
    if (rating) apiParams.push(`rating=${rating}`);
    if (sale === 'true') apiParams.push('saleOnly=true');
    
    // Update query string
    if (apiParams.length > 0) {
      apiQuery += `?${apiParams.join('&')}`;
    }
  }, [categorySlug, categories, minPrice, maxPrice, rating, sale]);
  
  // Search products if search query provided
  const searchQueryKey = searchQuery 
    ? `/api/products/search?query=${encodeURIComponent(searchQuery)}`
    : null;
  
  // Determine title based on filters
  let title = "Featured Products";
  
  if (searchQuery) {
    title = `Search Results for "${searchQuery}"`;
  } else if (categorySlug && categories) {
    const category = categories.find((c) => c.slug === categorySlug);
    if (category) {
      title = category.name;
    }
  } else if (sale === 'true') {
    title = "Sale Items";
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      {!searchQuery && !categorySlug && !sale && (
        <>
          <HeroBanner />
          <FeaturedCategories />
        </>
      )}
      
      <div className="flex flex-col lg:flex-row">
        <FilterSidebar />
        
        <div className="flex-1">
          <ProductGrid
            title={title}
            queryKey={searchQueryKey || apiQuery}
            emptyMessage={searchQuery ? `No results found for "${searchQuery}"` : "No products found matching your filters"}
          />
        </div>
      </div>
    </div>
  );
}
