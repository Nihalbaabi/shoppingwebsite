import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useCartStore } from '@/store/cart-store';
import { CheckoutForm } from '@/components/checkout-form';

export default function Checkout() {
  const [, navigate] = useLocation();
  const { items, refreshCart } = useCartStore();
  
  useEffect(() => {
    refreshCart();
  }, [refreshCart]);
  
  // If cart is empty, redirect to home
  useEffect(() => {
    if (items.length === 0) {
      navigate('/');
    }
  }, [items.length, navigate]);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <CheckoutForm />
    </div>
  );
}
