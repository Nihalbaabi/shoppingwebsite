import React, { useState, useEffect } from 'react';
import { useFetch } from '../hooks/useApi';
import { 
  API_CATEGORIES, 
  API_PRODUCTS,
  API_ORDERS
} from '../lib/api';
import { Category, Product, Order } from '@shared/schema';
import { useCart } from '@/hooks/useCart';
import { formatCurrency } from '@/lib/cart';

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<'categories' | 'products' | 'orders' | 'cart'>('categories');
  
  const { data: categories, loading: categoriesLoading } = useFetch<Category[]>(API_CATEGORIES);
  const { data: products, loading: productsLoading } = useFetch<Product[]>(API_PRODUCTS);
  const { data: orders, loading: ordersLoading } = useFetch<Order[]>(API_ORDERS);
  
  // Get cart data from CartContext
  const { cartItems, totalItems } = useCart();

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard - Database Viewer</h1>
      
      <div className="mb-6">
        <div className="flex border-b">
          <button 
            className={`px-4 py-2 ${activeTab === 'categories' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
            onClick={() => setActiveTab('categories')}
          >
            Categories
          </button>
          <button 
            className={`px-4 py-2 ${activeTab === 'products' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
            onClick={() => setActiveTab('products')}
          >
            Products
          </button>
          <button 
            className={`px-4 py-2 ${activeTab === 'orders' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
            onClick={() => setActiveTab('orders')}
          >
            Orders
          </button>
          <button 
            className={`px-4 py-2 ${activeTab === 'cart' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
            onClick={() => setActiveTab('cart')}
          >
            Cart {totalItems > 0 && `(${totalItems})`}
          </button>
        </div>
      </div>
      
      {/* Categories View */}
      {activeTab === 'categories' && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Categories ({categories?.length || 0})</h2>
          {categoriesLoading ? (
            <p>Loading categories...</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border">
                <thead>
                  <tr>
                    <th className="border px-4 py-2">ID</th>
                    <th className="border px-4 py-2">Name</th>
                    <th className="border px-4 py-2">Description</th>
                    <th className="border px-4 py-2">Icon</th>
                    <th className="border px-4 py-2">Featured</th>
                    <th className="border px-4 py-2">Image</th>
                  </tr>
                </thead>
                <tbody>
                  {categories?.map(category => (
                    <tr key={category.id}>
                      <td className="border px-4 py-2">{category.id}</td>
                      <td className="border px-4 py-2">{category.name}</td>
                      <td className="border px-4 py-2">{category.description}</td>
                      <td className="border px-4 py-2">{category.icon}</td>
                      <td className="border px-4 py-2">{category.featured ? 'Yes' : 'No'}</td>
                      <td className="border px-4 py-2">
                        {category.imageUrl ? (
                          <img src={category.imageUrl} alt={category.name} className="h-10 w-16 object-cover" />
                        ) : (
                          'No image'
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      
      {/* Products View */}
      {activeTab === 'products' && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Products ({products?.length || 0})</h2>
          {productsLoading ? (
            <p>Loading products...</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border">
                <thead>
                  <tr>
                    <th className="border px-4 py-2">ID</th>
                    <th className="border px-4 py-2">Name</th>
                    <th className="border px-4 py-2">Category ID</th>
                    <th className="border px-4 py-2">Price</th>
                    <th className="border px-4 py-2">Sale Price</th>
                    <th className="border px-4 py-2">Rating</th>
                    <th className="border px-4 py-2">In Stock</th>
                    <th className="border px-4 py-2">Featured</th>
                    <th className="border px-4 py-2">Image</th>
                  </tr>
                </thead>
                <tbody>
                  {products?.map(product => (
                    <tr key={product.id}>
                      <td className="border px-4 py-2">{product.id}</td>
                      <td className="border px-4 py-2">{product.name}</td>
                      <td className="border px-4 py-2">{product.categoryId}</td>
                      <td className="border px-4 py-2">${product.price.toFixed(2)}</td>
                      <td className="border px-4 py-2">{product.salePrice ? `$${product.salePrice.toFixed(2)}` : '-'}</td>
                      <td className="border px-4 py-2">{product.rating} ⭐ ({product.reviewCount})</td>
                      <td className="border px-4 py-2">{product.inStock ? 'Yes' : 'No'}</td>
                      <td className="border px-4 py-2">{product.isFeatured ? 'Yes' : 'No'}</td>
                      <td className="border px-4 py-2">
                        <img src={product.mainImage} alt={product.name} className="h-10 w-16 object-cover" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      
      {/* Orders View */}
      {activeTab === 'orders' && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Orders ({orders?.length || 0})</h2>
          {ordersLoading ? (
            <p>Loading orders...</p>
          ) : orders && orders.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border">
                <thead>
                  <tr>
                    <th className="border px-4 py-2">ID</th>
                    <th className="border px-4 py-2">Customer Name</th>
                    <th className="border px-4 py-2">Total</th>
                    <th className="border px-4 py-2">Status</th>
                    <th className="border px-4 py-2">Date</th>
                    <th className="border px-4 py-2">Address & Zipcode</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map(order => (
                    <tr key={order.id}>
                      <td className="border px-4 py-2">{order.id}</td>
                      <td className="border px-4 py-2">{order.customerName}</td>
                      <td className="border px-4 py-2">${order.total.toFixed(2)}</td>
                      <td className="border px-4 py-2">
                        <span className={`px-2 py-1 rounded text-xs text-white ${
                          order.status === 'completed' ? 'bg-green-500' : 
                          order.status === 'pending' ? 'bg-yellow-500' : 
                          'bg-gray-500'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="border px-4 py-2">{new Date(order.createdAt).toLocaleString()}</td>
                      <td className="border px-4 py-2">{order.address}, {order.zipcode}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p>No orders found. Orders will appear here when customers make purchases.</p>
          )}
        </div>
      )}
      
      {/* Cart View - Shows current items in the cart */}
      {activeTab === 'cart' && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Current Shopping Cart ({totalItems} items)</h2>
          {cartItems.length > 0 ? (
            <div>
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border">
                  <thead>
                    <tr>
                      <th className="border px-4 py-2">Product ID</th>
                      <th className="border px-4 py-2">Name</th>
                      <th className="border px-4 py-2">Image</th>
                      <th className="border px-4 py-2">Price</th>
                      <th className="border px-4 py-2">Sale Price</th>
                      <th className="border px-4 py-2">Quantity</th>
                      <th className="border px-4 py-2">Total</th>
                      {/* If you have variants/colors */}
                      <th className="border px-4 py-2">Variant</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cartItems.map(item => (
                      <tr key={`${item.product.id}-${item.color || 'default'}`}>
                        <td className="border px-4 py-2">{item.product.id}</td>
                        <td className="border px-4 py-2">{item.product.name}</td>
                        <td className="border px-4 py-2">
                          <img src={item.product.mainImage} alt={item.product.name} className="h-10 w-16 object-cover" />
                        </td>
                        <td className="border px-4 py-2">${item.product.price.toFixed(2)}</td>
                        <td className="border px-4 py-2">
                          {item.product.salePrice ? `$${item.product.salePrice.toFixed(2)}` : '-'}
                        </td>
                        <td className="border px-4 py-2">{item.quantity}</td>
                        <td className="border px-4 py-2">
                          ${((item.product.salePrice || item.product.price) * item.quantity).toFixed(2)}
                        </td>
                        <td className="border px-4 py-2">{item.color || 'Default'}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan={6} className="border px-4 py-2 text-right font-semibold">Cart Subtotal:</td>
                      <td colSpan={2} className="border px-4 py-2 font-semibold">
                        {formatCurrency(cartItems.reduce((total, item) => {
                          const itemPrice = item.product.salePrice || item.product.price;
                          return total + (itemPrice * item.quantity);
                        }, 0))}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
              
              <div className="mt-4 p-4 bg-gray-50 rounded border">
                <h3 className="font-semibold mb-2">Cart Summary</h3>
                <p>Note: Cart data is stored in browser memory (using React Context) and is not saved to the database until an order is placed.</p>
                <p className="mt-2">Cart items will be converted to Order Items in the database when checkout is completed.</p>
              </div>
            </div>
          ) : (
            <p>The shopping cart is empty. Add some products to see them here.</p>
          )}
        </div>
      )}
    </div>
  );
}