import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRoute } from 'wouter';
import { Product } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { StarRating } from '@/components/ui/star-rating';
import { useCartStore } from '@/store/cart-store';
import { formatCurrency } from '@/utils/format-currency';
import { useToast } from '@/hooks/use-toast';
import { Minus, Plus, ShoppingBag } from 'lucide-react';
import { ProductGrid } from '@/components/product-grid';

export default function ProductDetail() {
  const [, params] = useRoute<{ slug: string }>('/products/:slug');
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  
  const { addItem } = useCartStore();
  
  const { data: product, isLoading } = useQuery<Product>({
    queryKey: [`/api/products/${params?.slug}`],
  });
  
  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  const handleIncrement = () => {
    setQuantity(quantity + 1);
  };
  
  const handleAddToCart = () => {
    if (!product) return;
    
    addItem(product, quantity)
      .then(() => {
        toast({
          title: "Added to cart",
          description: `${product.name} has been added to your cart.`,
          variant: "default",
        });
        setQuantity(1);
      })
      .catch(() => {
        toast({
          title: "Error",
          description: "Failed to add item to cart. Please try again.",
          variant: "destructive",
        });
      });
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="flex flex-col md:flex-row md:space-x-8 animate-pulse">
          <div className="md:w-1/2 mb-6 md:mb-0">
            <div className="bg-gray-200 rounded-lg h-96"></div>
          </div>
          <div className="md:w-1/2">
            <div className="bg-gray-200 h-8 w-3/4 mb-4 rounded"></div>
            <div className="bg-gray-200 h-6 w-1/2 mb-4 rounded"></div>
            <div className="bg-gray-200 h-32 w-full mb-4 rounded"></div>
            <div className="bg-gray-200 h-10 w-1/3 mb-6 rounded"></div>
            <div className="bg-gray-200 h-12 w-full rounded"></div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <p className="text-gray-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <a href="/">Return to Home</a>
        </Button>
      </div>
    );
  }
  
  const displayPrice = product.salePrice || product.price;
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row md:space-x-8">
          {/* Product Image */}
          <div className="md:w-1/2 mb-6 md:mb-0">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-auto object-cover rounded-lg"
            />
          </div>
          
          {/* Product Details */}
          <div className="md:w-1/2">
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            
            <div className="flex items-center mb-4">
              <StarRating rating={product.rating} count={product.ratingCount} />
            </div>
            
            <div className="mb-6">
              <div className="flex items-baseline">
                <span className="text-2xl font-bold text-gray-900">
                  {formatCurrency(displayPrice)}
                </span>
                {product.salePrice && (
                  <span className="text-lg text-gray-500 line-through ml-2">
                    {formatCurrency(product.price)}
                  </span>
                )}
              </div>
              {product.salePrice && (
                <span className="inline-block mt-1 bg-accent/10 text-accent px-2 py-1 rounded text-sm font-medium">
                  Save {formatCurrency(product.price - product.salePrice)}
                </span>
              )}
            </div>
            
            <div className="mb-6">
              <p className="text-gray-700">{product.description}</p>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
              <div className="flex items-center space-x-3">
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={handleDecrement}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="text-center w-8">{quantity}</span>
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={handleIncrement}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <Button 
              onClick={handleAddToCart}
              className="w-full py-6"
              size="lg"
            >
              <ShoppingBag className="mr-2 h-5 w-5" /> Add to Cart
            </Button>
          </div>
        </div>
        
        {/* Related Products */}
        <div className="mt-16">
          <ProductGrid 
            title="Related Products" 
            queryKey={`/api/products?categoryId=${product.categoryId}`}
            emptyMessage="No related products found" 
          />
        </div>
      </div>
    </div>
  );
}
