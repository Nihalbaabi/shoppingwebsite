import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Checkbox } from './ui/checkbox';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Category } from '@shared/schema';
import { StarRating } from './ui/star-rating';

interface FilterValues {
  categories: number[];
  minPrice: number;
  maxPrice: number;
  rating: number | null;
}

export default function FilterSidebar() {
  const [location, setLocation] = useLocation();
  const [filter, setFilter] = useState<FilterValues>({
    categories: [],
    minPrice: 0,
    maxPrice: 1000,
    rating: null
  });
  
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Parse current URL parameters
  useEffect(() => {
    const params = new URLSearchParams(location.split('?')[1]);
    
    // Extract category IDs
    const categoryParam = params.get('category');
    if (categoryParam && categories) {
      const categoryObj = categories.find(c => c.slug === categoryParam);
      if (categoryObj) {
        setFilter(prev => ({
          ...prev,
          categories: [categoryObj.id]
        }));
      }
    }
    
    // Extract price range
    const minPrice = params.get('minPrice');
    const maxPrice = params.get('maxPrice');
    if (minPrice !== null && maxPrice !== null) {
      setFilter(prev => ({
        ...prev,
        minPrice: Number(minPrice),
        maxPrice: Number(maxPrice)
      }));
    }
    
    // Extract rating
    const rating = params.get('rating');
    if (rating !== null) {
      setFilter(prev => ({
        ...prev,
        rating: Number(rating)
      }));
    }
  }, [location, categories]);

  const handleCategoryChange = (categoryId: number, checked: boolean) => {
    setFilter(prev => {
      if (checked) {
        return {
          ...prev,
          categories: [...prev.categories, categoryId]
        };
      } else {
        return {
          ...prev,
          categories: prev.categories.filter(id => id !== categoryId)
        };
      }
    });
  };
  
  const handlePriceRangeChange = (value: number[]) => {
    setFilter(prev => ({
      ...prev,
      minPrice: value[0],
      maxPrice: value[1]
    }));
  };
  
  const handleMinPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(e.target.value);
    if (!isNaN(value) && value >= 0) {
      setFilter(prev => ({
        ...prev,
        minPrice: value
      }));
    }
  };
  
  const handleMaxPriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(e.target.value);
    if (!isNaN(value) && value >= 0) {
      setFilter(prev => ({
        ...prev,
        maxPrice: value
      }));
    }
  };
  
  const handleRatingChange = (rating: number) => {
    setFilter(prev => ({
      ...prev,
      rating: prev.rating === rating ? null : rating
    }));
  };
  
  const applyFilters = () => {
    const params = new URLSearchParams();
    
    // Apply category filter
    if (filter.categories.length === 1 && categories) {
      const category = categories.find(c => c.id === filter.categories[0]);
      if (category) {
        params.set('category', category.slug);
      }
    }
    
    // Apply price range filter
    if (filter.minPrice > 0 || filter.maxPrice < 1000) {
      params.set('minPrice', filter.minPrice.toString());
      params.set('maxPrice', filter.maxPrice.toString());
    }
    
    // Apply rating filter
    if (filter.rating !== null) {
      params.set('rating', filter.rating.toString());
    }
    
    // Build the new URL
    const queryString = params.toString();
    const newLocation = queryString ? `/?${queryString}` : '/';
    
    setLocation(newLocation);
  };

  return (
    <div className="lg:w-64 mb-6 lg:mb-0 lg:mr-8">
      <div className="bg-white rounded-lg shadow p-4">
        <h3 className="font-semibold text-lg mb-4">Filters</h3>
        
        {/* Category Filter */}
        <div className="mb-6">
          <h4 className="font-medium mb-2">Category</h4>
          <div className="space-y-2">
            {categories?.map((category) => (
              <div key={category.id} className="flex items-center">
                <Checkbox
                  id={`category-${category.id}`}
                  checked={filter.categories.includes(category.id)}
                  onCheckedChange={(checked) => 
                    handleCategoryChange(category.id, checked === true)
                  }
                  className="mr-2"
                />
                <Label htmlFor={`category-${category.id}`} className="text-sm">
                  {category.name}
                </Label>
              </div>
            ))}
          </div>
        </div>
        
        {/* Price Range Filter */}
        <div className="mb-6">
          <h4 className="font-medium mb-2">Price Range</h4>
          <div className="space-y-3">
            <div>
              <Slider
                defaultValue={[0, 1000]}
                value={[filter.minPrice, filter.maxPrice]}
                min={0}
                max={1000}
                step={10}
                onValueChange={handlePriceRangeChange}
                className="mt-2"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>$0</span>
                <span>$1000</span>
              </div>
            </div>
            <div className="flex space-x-2">
              <div>
                <Label className="text-xs text-gray-500">Min</Label>
                <Input
                  type="number"
                  placeholder="$0"
                  value={filter.minPrice}
                  onChange={handleMinPriceChange}
                  className="w-full text-sm"
                />
              </div>
              <div>
                <Label className="text-xs text-gray-500">Max</Label>
                <Input
                  type="number"
                  placeholder="$1000"
                  value={filter.maxPrice}
                  onChange={handleMaxPriceChange}
                  className="w-full text-sm"
                />
              </div>
            </div>
          </div>
        </div>
        
        {/* Ratings Filter */}
        <div className="mb-6">
          <h4 className="font-medium mb-2">Rating</h4>
          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((rating) => (
              <div key={rating} className="flex items-center">
                <Checkbox
                  id={`rating-${rating}`}
                  checked={filter.rating === rating}
                  onCheckedChange={(checked) => 
                    handleRatingChange(rating)
                  }
                  className="mr-2"
                />
                <Label htmlFor={`rating-${rating}`} className="text-sm flex items-center">
                  <StarRating rating={rating} size="sm" />
                  <span className="ml-1">& up</span>
                </Label>
              </div>
            ))}
          </div>
        </div>
        
        <Button className="w-full" onClick={applyFilters}>
          Apply Filters
        </Button>
      </div>
    </div>
  );
}
