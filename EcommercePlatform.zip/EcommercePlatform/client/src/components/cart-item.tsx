import { Minus, Plus, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { useCartStore } from '@/store/cart-store';
import { formatCurrency } from '@/utils/format-currency';

interface CartItemProps {
  id: number;
  name: string;
  price: number;
  salePrice?: number;
  imageUrl: string;
  quantity: number;
  variant?: string;
}

export function CartItem({ 
  id, 
  name, 
  price, 
  salePrice, 
  imageUrl, 
  quantity, 
  variant 
}: CartItemProps) {
  const { updateItemQuantity, removeItem } = useCartStore();
  
  const handleDecrement = () => {
    if (quantity > 1) {
      updateItemQuantity(id, quantity - 1);
    } else {
      removeItem(id);
    }
  };
  
  const handleIncrement = () => {
    updateItemQuantity(id, quantity + 1);
  };
  
  const handleRemove = () => {
    removeItem(id);
  };
  
  const displayPrice = salePrice || price;
  
  return (
    <div className="flex border-b pb-4">
      <img 
        src={imageUrl} 
        alt={name} 
        className="w-20 h-20 object-cover rounded"
      />
      <div className="ml-4 flex-1">
        <h3 className="text-sm font-medium">{name}</h3>
        {variant && <p className="text-sm text-gray-500">{variant}</p>}
        <div className="flex justify-between items-center mt-2">
          <div className="flex items-center border rounded">
            <Button 
              type="button" 
              variant="ghost" 
              size="sm" 
              className="px-2 py-1 h-auto text-gray-600 hover:bg-gray-100"
              onClick={handleDecrement}
            >
              <Minus className="h-3 w-3" />
            </Button>
            <span className="px-2 py-1 text-sm">{quantity}</span>
            <Button 
              type="button" 
              variant="ghost" 
              size="sm" 
              className="px-2 py-1 h-auto text-gray-600 hover:bg-gray-100"
              onClick={handleIncrement}
            >
              <Plus className="h-3 w-3" />
            </Button>
          </div>
          <span className="font-bold">{formatCurrency(displayPrice)}</span>
        </div>
      </div>
      <Button 
        variant="ghost" 
        size="sm" 
        className="text-gray-400 hover:text-status-error ml-2 p-1 h-auto"
        onClick={handleRemove}
      >
        <Trash2 className="h-5 w-5" />
      </Button>
    </div>
  );
}
