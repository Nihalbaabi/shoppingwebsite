import { ShoppingBag } from 'lucide-react';
import { Link } from 'wouter';
import { Button } from './ui/button';
import { StarRating } from './ui/star-rating';
import { Product } from '@shared/schema';
import { useCartStore } from '@/store/cart-store';
import { formatCurrency } from '@/utils/format-currency';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCartStore();
  const { toast } = useToast();
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    addItem(product, 1)
      .then(() => {
        toast({
          title: "Added to cart",
          description: `${product.name} has been added to your cart.`,
          variant: "default",
        });
      })
      .catch((err) => {
        toast({
          title: "Error",
          description: "Failed to add item to cart. Please try again.",
          variant: "destructive",
        });
      });
  };
  
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden hover:shadow-md transition">
      <Link href={`/products/${product.slug}`} className="block relative">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-48 object-cover"
        />
        {product.salePrice && (
          <div className="absolute top-2 right-2 bg-accent text-white text-xs font-bold px-2 py-1 rounded">
            SALE
          </div>
        )}
      </Link>
      <div className="p-4">
        <div className="flex items-center mb-1">
          <StarRating rating={product.rating} count={product.ratingCount} size="sm" />
        </div>
        <h3 className="font-medium text-gray-800 mb-1">{product.name}</h3>
        <div className="flex items-end mb-2">
          <span className="text-lg font-bold text-gray-800">
            {formatCurrency(product.salePrice || product.price)}
          </span>
          {product.salePrice && (
            <span className="text-sm text-gray-500 line-through ml-2">
              {formatCurrency(product.price)}
            </span>
          )}
        </div>
        <Button
          className="w-full py-2 flex items-center justify-center"
          onClick={handleAddToCart}
        >
          <ShoppingBag className="h-5 w-5 mr-1" />
          Add to Cart
        </Button>
      </div>
    </div>
  );
}
