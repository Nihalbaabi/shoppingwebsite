import { Link } from "wouter";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin,
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-gray-300">
      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">ShopEase</h3>
            <p className="text-sm mb-4">
              The best online shopping experience with wide product selection and fast delivery.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Instagram size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <Linkedin size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Shop</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/" className="hover:text-white transition">New Arrivals</Link></li>
              <li><Link href="/" className="hover:text-white transition">Best Sellers</Link></li>
              <li><Link href="/" className="hover:text-white transition">Deals & Promotions</Link></li>
              <li><Link href="/" className="hover:text-white transition">Clearance</Link></li>
              <li><Link href="/" className="hover:text-white transition">Gift Cards</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/" className="hover:text-white transition">Contact Us</Link></li>
              <li><Link href="/" className="hover:text-white transition">Help Center</Link></li>
              <li><Link href="/" className="hover:text-white transition">Shipping & Delivery</Link></li>
              <li><Link href="/" className="hover:text-white transition">Returns & Exchanges</Link></li>
              <li><Link href="/" className="hover:text-white transition">Size Guide</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white text-lg font-semibold mb-4">About</h3>
            <ul className="space-y-2 text-sm">
              <li><Link href="/" className="hover:text-white transition">Our Story</Link></li>
              <li><Link href="/" className="hover:text-white transition">Careers</Link></li>
              <li><Link href="/" className="hover:text-white transition">Corporate Responsibility</Link></li>
              <li><Link href="/" className="hover:text-white transition">Privacy Policy</Link></li>
              <li><Link href="/" className="hover:text-white transition">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm">© {new Date().getFullYear()} ShopEase. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-2">
            <div className="h-8 w-12 bg-gray-700 rounded"></div>
            <div className="h-8 w-12 bg-gray-700 rounded"></div>
            <div className="h-8 w-12 bg-gray-700 rounded"></div>
            <div className="h-8 w-12 bg-gray-700 rounded"></div>
          </div>
        </div>
      </div>
    </footer>
  );
}
