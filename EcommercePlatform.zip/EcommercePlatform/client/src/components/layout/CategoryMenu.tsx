import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import type { Category } from "@shared/schema";
import { 
  Shirt, 
  Smartphone, 
  Home, 
  Utensils, 
  Heart, 
  Gamepad 
} from "lucide-react";

interface CategoryMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const iconMap: Record<string, React.ReactNode> = {
  "fas fa-tshirt": <Shirt className="text-primary text-2xl mb-2" />,
  "fas fa-mobile-alt": <Smartphone className="text-primary text-2xl mb-2" />,
  "fas fa-home": <Home className="text-primary text-2xl mb-2" />,
  "fas fa-utensils": <Utensils className="text-primary text-2xl mb-2" />,
  "fas fa-heartbeat": <Heart className="text-primary text-2xl mb-2" />,
  "fas fa-gamepad": <Gamepad className="text-primary text-2xl mb-2" />,
};

export default function CategoryMenu({ isOpen, onClose }: CategoryMenuProps) {
  const { data: categories, isLoading } = useQuery({
    queryKey: ["/api/categories"],
  });

  if (!isOpen) return null;

  return (
    <div className="bg-gray-100 border-b border-gray-200">
      <div className="container mx-auto px-4 py-3">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
          {isLoading ? (
            Array(6).fill(0).map((_, index) => (
              <div 
                key={index} 
                className="flex flex-col items-center p-3 bg-white/50 animate-pulse rounded-lg h-24"
              />
            ))
          ) : (
            categories?.map((category: Category) => (
              <Link 
                key={category.id} 
                href={`/category/${category.id}`}
                onClick={onClose}
                className="flex flex-col items-center p-3 hover:bg-white hover:shadow rounded-lg transition"
              >
                {iconMap[category.icon] || (
                  <div className="text-primary text-2xl mb-2">
                    {category.icon.split(" ").pop()?.charAt(0).toUpperCase()}
                  </div>
                )}
                <span className="text-sm font-medium">{category.name}</span>
              </Link>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
