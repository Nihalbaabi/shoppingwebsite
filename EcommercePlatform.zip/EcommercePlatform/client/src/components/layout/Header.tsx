import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { Search, Menu, User, ShoppingCart } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import CategoryMenu from "./CategoryMenu";
import CartDrawer from "../cart/CartDrawer";

export default function Header() {
  const [location, setLocation] = useLocation();
  const { cartItems, totalItems } = useCart();
  const [searchQuery, setSearchQuery] = useState("");
  const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const toggleCategoryMenu = () => {
    setIsCategoryMenuOpen(!isCategoryMenuOpen);
  };

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
  };

  return (
    <>
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold text-primary">ShopEase</span>
            </Link>
            
            {/* Search Box - Desktop */}
            <div className="hidden md:flex flex-1 mx-8">
              <form onSubmit={handleSearch} className="relative w-full max-w-xl">
                <Input
                  type="text"
                  placeholder="Search for products..."
                  className="w-full pl-10 pr-4 py-2"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="absolute left-3 top-2.5 text-gray-400">
                  <Search size={18} />
                </div>
              </form>
            </div>
            
            {/* Navigation Items */}
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                className="hover:text-primary transition"
                onClick={toggleCategoryMenu}
              >
                <Menu className="mr-1 h-5 w-5" />
                <span className="hidden md:inline">Categories</span>
              </Button>
              <Button
                variant="ghost"
                className="hover:text-primary transition"
              >
                <User className="mr-1 h-5 w-5" />
                <span className="hidden md:inline">Account</span>
              </Button>
              <Button
                variant="ghost"
                className="relative hover:text-primary transition"
                onClick={toggleCart}
              >
                <ShoppingCart className="h-5 w-5" />
                <span className="hidden md:inline ml-1">Cart</span>
                {totalItems > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </Button>
              <Link href="/admin">
                <Button
                  variant="outline"
                  className="hover:bg-primary hover:text-white transition"
                >
                  Admin
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Search Box - Mobile */}
          <div className="md:hidden pb-3">
            <form onSubmit={handleSearch} className="relative w-full">
              <Input
                type="text"
                placeholder="Search for products..."
                className="w-full pl-10 pr-4 py-2"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div className="absolute left-3 top-2.5 text-gray-400">
                <Search size={18} />
              </div>
            </form>
          </div>
        </div>
      </header>
      
      {/* Category Menu */}
      <CategoryMenu isOpen={isCategoryMenuOpen} onClose={() => setIsCategoryMenuOpen(false)} />
      
      {/* Cart Drawer */}
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
}
