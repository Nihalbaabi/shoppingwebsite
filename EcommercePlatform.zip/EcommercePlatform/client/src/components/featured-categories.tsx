import { useQuery } from '@tanstack/react-query';
import { CategoryCard } from './category-card';
import { Category } from '@shared/schema';

export function FeaturedCategories() {
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });
  
  if (isLoading) {
    return (
      <div className="mb-12">
        <h2 className="text-xl font-semibold mb-6">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow p-4 text-center animate-pulse">
              <div className="bg-gray-200 rounded-full w-16 h-16 mx-auto mb-3"></div>
              <div className="bg-gray-200 h-4 rounded w-1/2 mx-auto"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="mb-12">
      <h2 className="text-xl font-semibold mb-6">Shop by Category</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {categories?.map((category) => (
          <CategoryCard key={category.id} category={category} />
        ))}
      </div>
    </div>
  );
}
