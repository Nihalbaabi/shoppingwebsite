import { Button } from './ui/button';
import { Link } from 'wouter';

export function HeroBanner() {
  return (
    <div className="relative rounded-xl overflow-hidden mb-8">
      <img
        src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80"
        alt="Special offers and discounts"
        className="w-full h-64 md:h-80 object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex flex-col justify-center px-6 md:px-12">
        <h1 className="text-white text-2xl md:text-4xl font-bold mb-2">Summer Sale</h1>
        <p className="text-white text-sm md:text-lg mb-4">Get up to 50% off on selected items</p>
        <Button className="w-fit" asChild>
          <Link href="/?sale=true">Shop Now</Link>
        </Button>
      </div>
    </div>
  );
}
