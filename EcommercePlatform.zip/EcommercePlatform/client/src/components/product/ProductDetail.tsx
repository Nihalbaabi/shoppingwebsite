import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/hooks/useCart";
import { formatCurrency } from "@/lib/cart";
import { X, Plus, Minus, Star, StarHalf, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { Product } from "@shared/schema";

interface ProductDetailProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
}

export default function ProductDetail({ product, isOpen, onClose }: ProductDetailProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState("Black");
  const [selectedImage, setSelectedImage] = useState(product.mainImage);

  if (!isOpen) return null;

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0 && value <= 10) {
      setQuantity(value);
    }
  };

  const increaseQuantity = () => {
    if (quantity < 10) {
      setQuantity(quantity + 1);
    }
  };

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedColor);
    toast({
      title: "Added to cart",
      description: `${quantity} ${quantity === 1 ? "item" : "items"} added to your cart.`,
    });
    onClose();
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  // Render stars based on rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-amber-400 text-amber-400" size={16} />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-amber-400 text-amber-400" size={16} />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <Star 
          key={`empty-star-${i}`} 
          className="text-amber-400" 
          size={16} 
          fill="none" 
        />
      );
    }

    return stars;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onClick={handleBackdropClick}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl max-h-screen overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="relative p-5 md:p-8">
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 z-10"
            onClick={onClose}
          >
            <X size={20} />
          </Button>
          
          <div className="md:flex -mx-4">
            <div className="md:w-1/2 px-4 mb-6 md:mb-0">
              <div className="relative pb-[100%] bg-gray-100 rounded-lg overflow-hidden mb-4">
                <img 
                  src={selectedImage} 
                  alt={product.name} 
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>
              {product.images && product.images.length > 0 && (
                <div className="grid grid-cols-4 gap-2">
                  {product.images.map((image, index) => (
                    <button 
                      key={index}
                      className={`bg-gray-100 rounded overflow-hidden ${
                        selectedImage === image ? 'ring-2 ring-primary' : ''
                      }`}
                      onClick={() => setSelectedImage(image)}
                    >
                      <div className="pb-[100%] relative">
                        <img 
                          src={image} 
                          alt={`${product.name} thumbnail ${index + 1}`} 
                          className="absolute inset-0 w-full h-full object-cover"
                        />
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            <div className="md:w-1/2 px-4">
              <span className="text-sm text-gray-500 mb-1">
                Category {product.categoryId}
              </span>
              <h2 className="text-2xl font-bold mb-2">{product.name}</h2>
              
              <div className="flex items-center mb-4">
                <div className="flex text-amber-400 mr-2">
                  {renderStars(product.rating)}
                </div>
                <span className="text-sm text-gray-500">{product.reviewCount} reviews</span>
              </div>
              
              <div className="mb-6">
                <span className="text-2xl font-bold text-primary">
                  {formatCurrency(product.price)}
                </span>
                {product.salePrice && (
                  <span className="text-sm text-gray-500 ml-2 line-through">
                    {formatCurrency(product.salePrice)}
                  </span>
                )}
                <span className="text-sm text-gray-500 ml-2">Tax included</span>
              </div>
              
              <div className="mb-6">
                <h3 className="text-sm font-semibold uppercase mb-2">Color</h3>
                <div className="flex space-x-3">
                  <button 
                    className={`w-8 h-8 rounded-full bg-gray-800 border-2 border-gray-800 focus:outline-none 
                      ${selectedColor === 'Black' ? 'ring-2 ring-primary ring-offset-1' : 'hover:ring-2 hover:ring-primary hover:ring-offset-1'}`}
                    onClick={() => setSelectedColor('Black')}
                    aria-label="Black"
                  />
                  <button 
                    className={`w-8 h-8 rounded-full bg-gray-300 border-2 border-gray-300 focus:outline-none 
                      ${selectedColor === 'Silver' ? 'ring-2 ring-primary ring-offset-1' : 'hover:ring-2 hover:ring-primary hover:ring-offset-1'}`}
                    onClick={() => setSelectedColor('Silver')}
                    aria-label="Silver"
                  />
                  <button 
                    className={`w-8 h-8 rounded-full bg-amber-700 border-2 border-amber-700 focus:outline-none 
                      ${selectedColor === 'Brown' ? 'ring-2 ring-primary ring-offset-1' : 'hover:ring-2 hover:ring-primary hover:ring-offset-1'}`}
                    onClick={() => setSelectedColor('Brown')}
                    aria-label="Brown"
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-sm font-semibold uppercase mb-2">Quantity</h3>
                <div className="flex">
                  <Button
                    variant="outline"
                    size="icon"
                    className="w-10 h-10 rounded-l-lg"
                    onClick={decreaseQuantity}
                  >
                    <Minus size={16} />
                  </Button>
                  <Input
                    type="number"
                    value={quantity}
                    onChange={handleQuantityChange}
                    min={1}
                    max={10}
                    className="w-16 h-10 text-center rounded-none border-x-0"
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    className="w-10 h-10 rounded-r-lg"
                    onClick={increaseQuantity}
                  >
                    <Plus size={16} />
                  </Button>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-sm font-semibold uppercase mb-2">Description</h3>
                <div className="text-gray-600">
                  <p className="mb-2">{product.description}</p>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row sm:space-x-4 space-y-3 sm:space-y-0">
                <Button 
                  className="flex-1"
                  onClick={handleAddToCart}
                >
                  Add to Cart
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                >
                  <Heart className="mr-2 h-4 w-4" /> Wishlist
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
