import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useCart } from "@/hooks/useCart";
import { formatCurrency } from "@/lib/cart";
import { Star, StarHalf } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  onViewDetails: (productId: number) => void;
}

export default function ProductCard({ product, onViewDetails }: ProductCardProps) {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [isHovered, setIsHovered] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  // Render stars based on rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-amber-400 text-amber-400" size={14} />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-amber-400 text-amber-400" size={14} />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <Star 
          key={`empty-star-${i}`} 
          className="text-amber-400" 
          size={14} 
          fill="none" 
        />
      );
    }

    return stars;
  };

  const getCategoryName = () => {
    // This is a simplified version. In a real app, you would fetch the category name
    return product.categoryId.toString();
  };

  return (
    <div 
      className={`bg-white rounded-lg shadow overflow-hidden transition transform ${
        isHovered ? "-translate-y-1 shadow-lg" : ""
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative">
        {product.isNew && (
          <Badge className="absolute top-2 left-2 bg-secondary">NEW</Badge>
        )}
        {product.salePrice && (
          <Badge className="absolute top-2 left-2 bg-accent">SALE</Badge>
        )}
        <div 
          className="cursor-pointer" 
          onClick={() => onViewDetails(product.id)}
        >
          <img 
            src={product.mainImage} 
            alt={product.name} 
            className="w-full h-48 object-cover"
          />
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <span className="block text-xs text-gray-500 mb-1">
              {getCategoryName()}
            </span>
            <a 
              href="#" 
              className="block font-semibold hover:text-primary"
              onClick={(e) => {
                e.preventDefault();
                onViewDetails(product.id);
              }}
            >
              {product.name}
            </a>
            <div className="flex items-center mt-1">
              <div className="flex text-amber-400 text-xs">
                {renderStars(product.rating)}
              </div>
              <span className="text-xs text-gray-500 ml-1">
                ({product.reviewCount})
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="font-bold text-primary">
              {formatCurrency(product.price)}
            </span>
            {product.salePrice && (
              <span className="block text-xs text-gray-500 line-through">
                {formatCurrency(product.salePrice)}
              </span>
            )}
          </div>
        </div>
        <Button 
          className="mt-3 w-full"
          onClick={handleAddToCart}
        >
          Add to Cart
        </Button>
      </div>
    </div>
  );
}
