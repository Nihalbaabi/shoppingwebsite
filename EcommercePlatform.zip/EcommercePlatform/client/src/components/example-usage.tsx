import React from 'react';
import { useFetch, usePost } from '../hooks/useApi';
import { 
  API_CATEGORIES, 
  API_PRODUCTS_FEATURED,
  API_CATEGORY_PRODUCTS,
  API_PRODUCTS_SEARCH,
  API_ORDERS
} from '../lib/api';
import { Category, Product, InsertOrder } from '@shared/schema';

// Example component showing how to use the API endpoints
export function ExampleApiUsage() {
  // Fetch all categories
  const { data: categories, loading: categoriesLoading } = useFetch<Category[]>(API_CATEGORIES);
  
  // Fetch featured products
  const { data: featuredProducts, loading: productsLoading } = useFetch<Product[]>(API_PRODUCTS_FEATURED);
  
  // Example of getting products for a specific category (e.g., category ID 1)
  const categoryId = 1;
  const { data: categoryProducts } = useFetch<Product[]>(API_CATEGORY_PRODUCTS(categoryId));
  
  // Example of searching products
  const searchQuery = 'watch';
  const { data: searchResults } = useFetch<Product[]>(API_PRODUCTS_SEARCH(searchQuery));
  
  // Example of posting an order
  const { submit, loading: orderSubmitLoading } = usePost<InsertOrder, any>();
  
  const handleSubmitOrder = async () => {
    // Example order data
    const orderData: InsertOrder = {
      customerEmail: 'customer@example.com',
      customerName: 'John Doe',
      address: '123 Main St',
      city: 'Anytown',
      state: 'CA',
      zipcode: '12345',
      total: 99.99,
      paymentMethod: 'credit_card',
      createdAt: new Date().toISOString()
    };
    
    try {
      const result = await submit(API_ORDERS, orderData);
      console.log('Order created:', result);
    } catch (error) {
      console.error('Failed to create order:', error);
    }
  };
  
  return (
    <div>
      <h2>API Endpoint Example Usage</h2>
      
      <h3>Categories</h3>
      {categoriesLoading ? (
        <p>Loading categories...</p>
      ) : (
        <ul>
          {categories?.map(category => (
            <li key={category.id}>{category.name}</li>
          ))}
        </ul>
      )}
      
      <h3>Featured Products</h3>
      {productsLoading ? (
        <p>Loading products...</p>
      ) : (
        <ul>
          {featuredProducts?.map(product => (
            <li key={product.id}>{product.name} - ${product.price}</li>
          ))}
        </ul>
      )}
      
      <h3>Products in Category {categoryId}</h3>
      <ul>
        {categoryProducts?.map(product => (
          <li key={product.id}>{product.name}</li>
        ))}
      </ul>
      
      <h3>Search Results for "{searchQuery}"</h3>
      <ul>
        {searchResults?.map(product => (
          <li key={product.id}>{product.name}</li>
        ))}
      </ul>
      
      <button 
        onClick={handleSubmitOrder} 
        disabled={orderSubmitLoading}
      >
        {orderSubmitLoading ? 'Creating Order...' : 'Create Example Order'}
      </button>
    </div>
  );
}