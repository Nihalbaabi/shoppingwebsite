import { Category } from '@shared/schema';
import { Link } from 'wouter';
import { 
  Smartphone, 
  Shirt,
  Home,
  Paintbrush,
  Dumbbell,
  BookOpen,
  LucideIcon
} from 'lucide-react';

interface CategoryCardProps {
  category: Category;
}

// Map of category icons
const iconMap: Record<string, LucideIcon> = {
  smartphone: Smartphone,
  shirt: Shirt,
  home: Home,
  paintbrush: Paintbrush,
  dumbbell: Dumbbell,
  'book-open': BookOpen
};

// Map of background colors
const bgColorMap: Record<string, string> = {
  blue: 'bg-blue-100',
  green: 'bg-green-100',
  amber: 'bg-amber-100',
  pink: 'bg-pink-100',
  purple: 'bg-purple-100',
  gray: 'bg-gray-100'
};

// Map of text colors
const textColorMap: Record<string, string> = {
  blue: 'text-primary',
  green: 'text-secondary',
  amber: 'text-accent',
  pink: 'text-pink-500',
  purple: 'text-purple-500',
  gray: 'text-gray-600'
};

export function CategoryCard({ category }: CategoryCardProps) {
  const Icon = iconMap[category.icon] || Smartphone;
  const bgColor = bgColorMap[category.color] || 'bg-gray-100';
  const textColor = textColorMap[category.color] || 'text-gray-600';

  return (
    <Link href={`/?category=${category.slug}`} className="bg-white rounded-lg shadow p-4 text-center hover:shadow-md transition">
      <div className={`${bgColor} rounded-full w-16 h-16 mx-auto mb-3 flex items-center justify-center`}>
        <Icon className={`h-8 w-8 ${textColor}`} />
      </div>
      <h3 className="font-medium">{category.name}</h3>
    </Link>
  );
}
