import { Star } from "lucide-react";

interface StarRatingProps {
  rating: number;
  count?: number;
  size?: "sm" | "md";
}

export function StarRating({ rating, count, size = "md" }: StarRatingProps) {
  const wholeStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - wholeStars - (hasHalfStar ? 1 : 0);
  
  const starSize = size === "sm" ? "h-4 w-4" : "h-5 w-5";
  
  return (
    <div className="flex items-center">
      <div className="flex text-yellow-400">
        {[...Array(wholeStars)].map((_, i) => (
          <Star key={`full-${i}`} className={`${starSize} fill-current`} />
        ))}
        
        {hasHalfStar && (
          <span className="relative">
            <Star className={`${starSize} text-gray-300 fill-current`} />
            <span className="absolute top-0 left-0 overflow-hidden w-1/2">
              <Star className={`${starSize} text-yellow-400 fill-current`} />
            </span>
          </span>
        )}
        
        {[...Array(emptyStars)].map((_, i) => (
          <Star key={`empty-${i}`} className={`${starSize} text-gray-300 fill-current`} />
        ))}
      </div>
      
      {count !== undefined && (
        <span className="text-xs text-gray-500 ml-1">({count})</span>
      )}
    </div>
  );
}
