import { useCart } from "@/hooks/useCart";
import { 
  calculateSubtotal, 
  calculateTax, 
  calculateTotal, 
  formatCurrency 
} from "@/lib/cart";
import { X, Plus, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import CheckoutForm from "@/components/checkout/CheckoutForm";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const { 
    cartItems, 
    increaseQuantity, 
    decreaseQuantity, 
    removeFromCart,
    clearCart
  } = useCart();
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  if (!isOpen) return null;

  const subtotal = calculateSubtotal(cartItems);
  const tax = calculateTax(subtotal);
  const total = calculateTotal(subtotal, tax);

  const handleCheckout = () => {
    setIsCheckoutOpen(true);
  };

  return (
    <>
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-50"
        onClick={onClose}
      >
        <div 
          className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-lg transform transition-transform duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex flex-col h-full">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-bold">
                Your Cart ({cartItems.length})
              </h3>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={20} />
              </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4">
              {cartItems.length === 0 ? (
                <div className="text-center py-10">
                  <p className="text-gray-500 mb-4">Your cart is empty</p>
                  <Button onClick={onClose}>Continue Shopping</Button>
                </div>
              ) : (
                cartItems.map((item) => (
                  <div 
                    key={`${item.productId}-${item.color || 'default'}`} 
                    className="flex items-center py-4 border-b border-gray-200"
                  >
                    <img 
                      src={item.product.mainImage} 
                      alt={item.product.name} 
                      className="w-16 h-16 object-cover rounded"
                    />
                    <div className="ml-4 flex-1">
                      <h4 className="font-medium">{item.product.name}</h4>
                      {item.color && (
                        <p className="text-sm text-gray-500">Color: {item.color}</p>
                      )}
                      <div className="flex items-center mt-1">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-6 w-6 p-0"
                          onClick={() => decreaseQuantity(item.productId, item.color)}
                        >
                          <Minus size={12} />
                        </Button>
                        <span className="mx-2 w-8 text-center">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-6 w-6 p-0"
                          onClick={() => increaseQuantity(item.productId, item.color)}
                        >
                          <Plus size={12} />
                        </Button>
                      </div>
                    </div>
                    <div className="ml-4 text-right">
                      <span className="font-bold text-primary">
                        {formatCurrency(
                          (item.product.salePrice || item.product.price) * 
                          item.quantity
                        )}
                      </span>
                      <Button
                        variant="ghost"
                        className="block mt-2 text-sm text-gray-500 hover:text-red-500 p-0 h-auto"
                        onClick={() => removeFromCart(item.productId, item.color)}
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
            
            {cartItems.length > 0 && (
              <div className="p-4 border-t border-gray-200">
                <div className="mb-4">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="font-semibold">{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Shipping</span>
                    <span className="font-semibold">$0.00</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600">Tax</span>
                    <span className="font-semibold">{formatCurrency(tax)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-200">
                    <span>Total</span>
                    <span className="text-primary">{formatCurrency(total)}</span>
                  </div>
                </div>
                <Button 
                  className="w-full mb-2"
                  onClick={handleCheckout}
                >
                  Proceed to Checkout
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={onClose}
                >
                  Continue Shopping
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {isCheckoutOpen && (
        <CheckoutForm
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          cartItems={cartItems}
          subtotal={subtotal}
          tax={tax}
          total={total}
          onOrderComplete={() => {
            clearCart();
            setIsCheckoutOpen(false);
          }}
        />
      )}
    </>
  );
}
