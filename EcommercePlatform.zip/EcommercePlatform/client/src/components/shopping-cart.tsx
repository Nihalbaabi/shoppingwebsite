import { useEffect } from 'react';
import { X } from 'lucide-react';
import { useLocation } from 'wouter';
import { Button } from './ui/button';
import { CartItem } from './cart-item';
import { useCartStore } from '@/store/cart-store';
import { formatCurrency } from '@/utils/format-currency';

export function ShoppingCart() {
  const [, navigate] = useLocation();
  const { 
    isOpen, 
    closeCart, 
    items, 
    isLoading,
    getSubtotal,
    getTotalItems
  } = useCartStore();

  // Close cart drawer when pressing escape key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeCart();
    };
    
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [closeCart]);

  const handleProceedToCheckout = () => {
    closeCart();
    navigate('/checkout');
  };

  const handleContinueShopping = () => {
    closeCart();
  };

  // Calculate cart totals
  const subtotal = getSubtotal();
  const totalItems = getTotalItems();

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={closeCart}
        />
      )}

      {/* Cart Drawer */}
      <div 
        className={`fixed top-0 right-0 w-full md:w-96 h-full bg-white shadow-lg transform transition-transform duration-300 z-50 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="text-lg font-semibold">
              Your Cart ({totalItems})
            </h2>
            <Button variant="ghost" size="sm" onClick={closeCart} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </Button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {isLoading ? (
              <div className="py-8 text-center text-gray-500">Loading cart...</div>
            ) : items.length === 0 ? (
              <div className="py-8 text-center text-gray-500">Your cart is empty</div>
            ) : (
              items.map((item) => (
                <CartItem
                  key={item.id}
                  id={item.id}
                  name={item.product.name}
                  price={item.product.price}
                  salePrice={item.product.salePrice}
                  imageUrl={item.product.imageUrl}
                  quantity={item.quantity}
                />
              ))
            )}
          </div>
          
          <div className="border-t p-4 space-y-4">
            <div className="flex justify-between font-medium">
              <span>Subtotal</span>
              <span>{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-500">
              <span>Shipping</span>
              <span>Calculated at checkout</span>
            </div>
            <div className="flex justify-between text-lg font-bold">
              <span>Total</span>
              <span>{formatCurrency(subtotal)}</span>
            </div>
            
            <Button
              className="w-full py-3"
              disabled={items.length === 0}
              onClick={handleProceedToCheckout}
            >
              Proceed to Checkout
            </Button>
            
            <Button
              variant="outline" 
              className="w-full py-3"
              onClick={handleContinueShopping}
            >
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
