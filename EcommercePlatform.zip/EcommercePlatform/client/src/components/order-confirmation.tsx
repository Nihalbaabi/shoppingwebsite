import { CheckCircle } from 'lucide-react';
import { Button } from './ui/button';

interface OrderConfirmationProps {
  orderNumber: string;
  onContinueShopping: () => void;
}

export function OrderConfirmation({ orderNumber, onContinueShopping }: OrderConfirmationProps) {
  return (
    <div className="bg-white rounded-lg shadow-xl p-8 max-w-md mx-auto text-center my-8">
      <div className="bg-green-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
        <CheckCircle className="h-8 w-8 text-status-success" />
      </div>
      <h2 className="text-2xl font-semibold mb-2">Order Confirmed!</h2>
      <p className="text-gray-600 mb-6">
        Your order has been placed successfully. You will receive a confirmation email shortly.
      </p>
      <div className="bg-gray-50 rounded-lg p-4 mb-6">
        <div className="text-sm text-gray-600 mb-1">Order Number</div>
        <div className="font-bold">{orderNumber}</div>
      </div>
      <Button className="w-full" onClick={onContinueShopping}>
        Continue Shopping
      </Button>
    </div>
  );
}
