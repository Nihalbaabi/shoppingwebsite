import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";

interface OrderConfirmationProps {
  isOpen: boolean;
  orderNumber: string;
  onClose: () => void;
}

export default function OrderConfirmation({ 
  isOpen, 
  orderNumber, 
  onClose 
}: OrderConfirmationProps) {
  if (!isOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4" onClick={handleBackdropClick}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="p-6 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="text-2xl text-green-500" size={32} />
          </div>
          <h2 className="text-2xl font-bold mb-2">Order Placed!</h2>
          <p className="text-gray-600 mb-6">
            Your order has been successfully placed. We've sent a confirmation email with all the details.
          </p>
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <p className="text-sm text-gray-600">Order Number</p>
            <p className="font-bold text-lg">{orderNumber}</p>
          </div>
          <Button 
            className="w-full"
            onClick={onClose}
          >
            Continue Shopping
          </Button>
        </div>
      </div>
    </div>
  );
}
